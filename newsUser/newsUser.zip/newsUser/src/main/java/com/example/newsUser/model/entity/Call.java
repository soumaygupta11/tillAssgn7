package com.example.newsUser.model.entity;

import javax.persistence.*;

@Entity
@Table(name = "calls")
public class Call {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String endpoint;
    private String request;
    private String response;
    private String timetaken;

    public String getEndpoint() {
        return endpoint;
    }

    public String getRequest() {
        return request;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public void setTimetaken(String timetaken) {
        this.timetaken = timetaken;
    }

    public String getResponse() {
        return response;
    }

    public String getTimetaken() {
        return timetaken;
    }

    private Call() {
    }
    public Call(String endpoint, String request, String response, String timetaken) {
        this.endpoint = endpoint;
        this.request = request;
        this.response = response;
        this.timetaken = timetaken;
    }


}
