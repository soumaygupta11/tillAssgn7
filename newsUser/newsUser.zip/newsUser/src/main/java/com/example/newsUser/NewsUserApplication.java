package com.example.newsUser;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsUserApplication.class, args);
	}

}
