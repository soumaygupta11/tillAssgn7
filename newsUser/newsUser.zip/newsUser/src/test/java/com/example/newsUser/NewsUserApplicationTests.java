package com.example.newsUser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewsUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
